package com.hussienalrubaye.phplogin;

/**
 * Created by hussienalrubaye on 9/9/16.
 */

// adapter class
public class AdapterItems
{
    public   int ID;
    public  String UserName;
    public  String Password;
    //for news details
    AdapterItems( int ID, String UserName,String Password)
    {
        this. ID=ID;
        this. UserName=UserName;
        this. Password=Password;
    }
}
